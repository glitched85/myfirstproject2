import ComponentView from '../../dom_components/view/ComponentView';
import ComponentDataCollection from '../model/data_collection/ComponentDataCollection';

export default class ComponentDataCollectionView extends ComponentView<ComponentDataCollection> {}
