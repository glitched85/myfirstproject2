<template>
  <div class="demo-container">
    <slot />
  </div>
</template>

<style scoped>
.demo-container {
  min-height: 20px;
  border: 1px solid #eee;
  border-radius: 2px;
  padding: 25px 35px;
}
</style>
