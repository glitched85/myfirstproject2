./packages/core/README.md
