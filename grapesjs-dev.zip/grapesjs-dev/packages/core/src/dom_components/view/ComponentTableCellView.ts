import ComponentTableCell from '../model/ComponentTableCell';
import ComponentView from './ComponentView';

export default class ComponentTableCellView extends ComponentView<ComponentTableCell> {}
