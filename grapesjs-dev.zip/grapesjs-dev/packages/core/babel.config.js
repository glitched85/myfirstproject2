/** @type {import('@babel/core')} */
module.exports = {
  env: {
    test: {
      presets: ['@babel/preset-env', '@babel/preset-typescript'],
    },
  },
};
