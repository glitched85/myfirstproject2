import ComponentTableFoot from '../model/ComponentTableFoot';
import ComponentView from './ComponentView';

export default class ComponentTableFootView extends ComponentView<ComponentTableFoot> {}
