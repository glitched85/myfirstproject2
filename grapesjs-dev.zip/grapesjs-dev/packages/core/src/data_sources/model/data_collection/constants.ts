export const DataCollectionType = 'data-collection';
export const DataCollectionItemType = 'data-collection-item';
export const keyCollectionDefinition = 'dataResolver';
