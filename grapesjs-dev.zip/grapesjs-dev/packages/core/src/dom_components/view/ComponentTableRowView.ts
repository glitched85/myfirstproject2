import ComponentTableRow from '../model/ComponentTableRow';
import ComponentView from './ComponentView';

export default class ComponentTableRowView extends ComponentView<ComponentTableRow> {}
